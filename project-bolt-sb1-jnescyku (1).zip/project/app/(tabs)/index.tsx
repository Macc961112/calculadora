import { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// Constantes para el cálculo
const POSITIONS = 5;
const MAX_LOSS_PERCENTAGE = 0.01; // 1%
const PIPS_PER_DOLLAR = 10; // 1 USD = 10 pips en oro

const PRESET_ACCOUNTS = [
  { balance: 5000, lotSize: 0.10 },
  { balance: 10000, lotSize: 0.20 },
  { balance: 25000, lotSize: 0.50 },
  { balance: 50000, lotSize: 1.00 },
  { balance: 100000, lotSize: 2.00 },
  { balance: 200000, lotSize: 4.00 },
  { balance: 400000, lotSize: 8.00 },
];

function calculatePositions(accountSize: number, stopLossUSD: number): number[] {
  // Encontrar el preset más cercano para sugerir el lotaje base
  const preset = PRESET_ACCOUNTS.find(p => p.balance === accountSize) || {
    lotSize: (accountSize / 50000) // Proporción base: 50k = 1 lote
  };

  // Dividir el lotaje total entre las 5 posiciones
  const lotPerPosition = preset.lotSize / POSITIONS;
  
  // Crear array con el mismo lotaje para cada posición
  return Array(POSITIONS).fill(Number(lotPerPosition.toFixed(2)));
}

export default function Calculator() {
  const [accountSize, setAccountSize] = useState('');
  const [stopLossUSD, setStopLossUSD] = useState('10');
  const [results, setResults] = useState<number[]>([]);
  const [maxLoss, setMaxLoss] = useState(0);

  const handleCalculate = () => {
    const account = parseFloat(accountSize);
    const stop = parseFloat(stopLossUSD);
    
    if (isNaN(account) || isNaN(stop)) return;
    
    const positions = calculatePositions(account, stop);
    const totalLoss = account * MAX_LOSS_PERCENTAGE;
    
    setResults(positions);
    setMaxLoss(totalLoss);
  };

  const handlePresetSelect = (balance: number) => {
    setAccountSize(balance.toString());
    handleCalculate();
  };

  const handleClear = () => {
    setAccountSize('');
    setStopLossUSD('10');
    setResults([]);
    setMaxLoss(0);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        <View style={styles.presetContainer}>
          <Text style={styles.sectionTitle}>Tamaños de Cuenta Predefinidos</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.presetScroll}>
            {PRESET_ACCOUNTS.map((account, index) => (
              <TouchableOpacity
                key={index}
                style={styles.presetButton}
                onPress={() => handlePresetSelect(account.balance)}
              >
                <Text style={styles.presetAmount}>${(account.balance/1000)}K</Text>
                <Text style={styles.presetLot}>{account.lotSize} lotes</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Tamaño de Cuenta ($)</Text>
          <TextInput
            style={styles.input}
            value={accountSize}
            onChangeText={setAccountSize}
            keyboardType="numeric"
            placeholder="Ej: 10000"
          />
          
          <Text style={styles.label}>Stop Loss (USD)</Text>
          <TextInput
            style={styles.input}
            value={stopLossUSD}
            onChangeText={setStopLossUSD}
            keyboardType="numeric"
            placeholder="Ej: 10"
          />
        </View>

        <View style={styles.infoContainer}>
          <Text style={styles.infoText}>
            • Riesgo máximo: 1% de la cuenta{'\n'}
            • Posiciones: 5 entradas equitativas{'\n'}
            • 1 USD = 10 pips en oro{'\n'}
            • Stop Loss actual: {stopLossUSD} USD = {Number(stopLossUSD) * PIPS_PER_DOLLAR} pips
          </Text>
        </View>

        {results.length > 0 && (
          <View style={styles.resultsContainer}>
            <Text style={styles.sectionTitle}>Distribución de Lotes</Text>
            {results.map((lotSize, index) => (
              <View key={index} style={styles.resultRow}>
                <Text style={styles.resultName}>Posición {index + 1}</Text>
                <Text style={styles.resultValue}>{lotSize} lotes</Text>
              </View>
            ))}
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Lotes Totales:</Text>
              <Text style={styles.totalValue}>
                {results.reduce((a, b) => a + b, 0)} lotes
              </Text>
            </View>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Pérdida Máxima:</Text>
              <Text style={styles.totalValue}>
                ${maxLoss.toFixed(2)}
              </Text>
            </View>
          </View>
        )}

        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={[styles.button, styles.clearButton]} 
            onPress={handleClear}
          >
            <Text style={styles.buttonText}>Limpiar</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.button, styles.calculateButton]} 
            onPress={handleCalculate}
          >
            <Text style={styles.buttonText}>Calcular</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  presetContainer: {
    marginBottom: 16,
  },
  presetScroll: {
    flexDirection: 'row',
    paddingVertical: 8,
  },
  presetButton: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    minWidth: 100,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  presetAmount: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1976d2',
    marginBottom: 4,
  },
  presetLot: {
    fontSize: 14,
    color: '#666',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  inputContainer: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  infoContainer: {
    backgroundColor: '#e3f2fd',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  infoText: {
    fontSize: 14,
    color: '#1976d2',
    lineHeight: 20,
  },
  resultsContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  resultName: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  resultValue: {
    fontSize: 16,
    color: '#2196f3',
    fontWeight: '600',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 16,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f44336',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  button: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  clearButton: {
    backgroundColor: '#ffebee',
  },
  calculateButton: {
    backgroundColor: '#e3f2fd',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
});